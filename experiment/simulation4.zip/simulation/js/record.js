




function datasheet(){
 
 
  document.getElementById("n").innerHTML = "1124";
  document.getElementById("pd").innerHTML = "1";
  document.getElementById("ps").innerHTML = "0";
  document.getElementById("r1").innerHTML = "21.5";
  document.getElementById("r2").innerHTML = "4";
  document.getElementById("r").innerHTML = "17.5";
  document.getElementById("t").innerHTML = "30";
  document.getElementById("nb").innerHTML = "1522";
  document.getElementById("pdb").innerHTML = "3";
  document.getElementById("psb").innerHTML = "0";
  document.getElementById("r1b").innerHTML = "31";
  document.getElementById("r2b").innerHTML = "3";
  document.getElementById("rb").innerHTML = "28";
  document.getElementById("tb").innerHTML = "30";
  document.getElementById("nc").innerHTML = "1847";
  document.getElementById("pdc").innerHTML = "4";
  document.getElementById("psc").innerHTML = "0";
  document.getElementById("r1c").innerHTML = "40";
  document.getElementById("r2c").innerHTML = "3";
  document.getElementById("rc").innerHTML = "37";
  document.getElementById("tc").innerHTML = "30";
  document.getElementById("nd").innerHTML = "2775";
  document.getElementById("pdd").innerHTML = "8";
  document.getElementById("psd").innerHTML = "0";
  document.getElementById("r1d").innerHTML = "48";
  document.getElementById("r2d").innerHTML = "3";
  document.getElementById("rd").innerHTML = "45";
  document.getElementById("td").innerHTML = "30";

  document.getElementById("p").innerHTML = "10";
  document.getElementById("tp").innerHTML = "77";
  document.getElementById("ei").innerHTML = "0.145";
  document.getElementById("es").innerHTML = "0.116";
  document.getElementById("h").innerHTML = "11";
  document.getElementById("pa").innerHTML = "10";
  document.getElementById("tpa").innerHTML = "56";
  document.getElementById("eia").innerHTML = "0.20";
  document.getElementById("esa").innerHTML = "0.16";
  document.getElementById("ha").innerHTML = "31";
  document.getElementById("pb").innerHTML = "10";
  document.getElementById("tpb").innerHTML = "39";
  document.getElementById("eib").innerHTML = "0.23";
  document.getElementById("esb").innerHTML = "0.23";
  document.getElementById("hb").innerHTML = "41";
  document.getElementById("pc").innerHTML = "10";
  document.getElementById("tpc").innerHTML = "20";
  document.getElementById("eic").innerHTML = "0.44";
  document.getElementById("esc").innerHTML = "0.44";
  document.getElementById("hc").innerHTML = "81";
 
  
}



